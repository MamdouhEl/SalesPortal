var express = require("express");
const jwt = require("jsonwebtoken");


var ActiveDirectory = require('activedirectory');



var username = '';

var password = '';


const router = express.Router();

router.post("/login", (req, res, next) => {
  username = 'corp\\' + req.body.username;
  username2 = req.body.username;
  password = req.body.password;
  // console.log(username);
  // console.log(password);
  // console.log(username2);


if (username2.includes("@emc.com")) {
  var config = { url: 'ldap://corp.emc.com',
               baseDN: 'dc=emc,dc=com',
               username: username2,
               password: password }
  var ad = new ActiveDirectory(config);
  ad.authenticate(username2, password, function(err, auth) {

    if (err) {
      console.log('ERROR: '+JSON.stringify(err));
      res.status(404).json({token: null});
    }

    if (auth) {
      console.log('Authenticated!');
      const token = jwt.sign({username: username2}, 'nlsanfiyewfinwiuybyfwqegfewmvrenqjbevrnhjj', {expiresIn: "1h"});
      res.status(200).json({
        token: token,
        expiresIn: 3600
      });
    }
    else {
      console.log('Authentication failed!');
    }
  });
}else{
  var config = { url: 'ldap://corp.emc.com',
               baseDN: 'dc=emc,dc=com',
               username: username,
               password: password }
  var ad = new ActiveDirectory(config);
  ad.authenticate(username, password, function(err, auth) {
    if (err) {
      console.log('ERROR: '+JSON.stringify(err));
      res.status(404).json({token: null});
      return;
    }

    if (auth) {
      console.log('Authenticated!');
      const token = jwt.sign({username: username}, 'nlsanfiyewfinwiuybyfwqegfewmvrenqjbevrnhjj', {expiresIn: "1h"});
      res.status(200).json({
        token: token,
        expiresIn: 3600
      });
    }
    else {
      console.log('Authentication failed!');
    }
  });
}

});


module.exports = router;
