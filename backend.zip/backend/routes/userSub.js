const express = require('express');

const Exist = require("../model/post");

const router = express.Router();

router.get(":username", (req, res, next) => {

  Exist.find({Submitter: req.params.username}).then(documents => {
    console.log(documents);
    res.status(200).json({
      message: "Posts fetched successfully",
      Posts: documents
  });

  });
});