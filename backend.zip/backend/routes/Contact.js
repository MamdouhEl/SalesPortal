
const express = require('express');
const router3 = express.Router();
const NewContact = require("../model/newContact");





router3.get("", (req, res, next) => {
  NewContact.find().then(documents => {
    console.log(documents);
    res.status(200).json({
      message: "Posts fetched successfully",
      Posts: documents
  });

  });
});

router3.post("", (req, res, next) => {
  const Contact = new NewContact({
    id: req.body.id,
    Submitter: req.body.Submitter,
    Customer: req.body.Customer,
    ContactName: req.body.ContactName,
    ContactEmail: req.body.ContactEmail,
    ContactPhone: req.body.ContactPhone,
    ContactPosition: req.body.ContactPosition,
    Comment: req.body.Comment,
    Status: req.body.Status,
    Points: req.body.Points
  });
  console.log(Contact);
  Contact.save();
  res.status(201).json({
    message: "Submission Successful!"
  });
});

router3.put("/:id", (req, res, next) => {

  if(req.body.Points != null){
    Contact.updateOne({id: req.body.Id}, { Status: req.body.Status, Points: req.body.Points })
  .then(result => {
    console.log(result);

    res.status(200).json({message: "Points and Status Updated!"});
  });
  }else{
    Contact.updateOne({id: req.body.Id}, { CompanyName: req.body.CompanyName, ContactName: req.body.ContactName, ContactPhone: req.body.ContactPhone, ContactEmail: req.body.ContactEmail, Product: req.body.Product, Description: req.body.Description, Status: req.body.Status })
  .then(result => {
    console.log(result);
    res.status(200).json({message: "Post Updated!"});
  });
  }




});

module.exports = router3;
