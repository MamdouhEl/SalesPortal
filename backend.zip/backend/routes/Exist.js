const express = require('express');

const Exist = require("../model/post");

const router = express.Router();


router.get("", (req, res, next) => {
  Exist.find().then(documents => {
    //console.log(documents);
    res.status(200).json({
      message: "Posts fetched successfully",
      Posts: documents
  });

  });
});

router.get(":user", (req, res, next) => {

  Exist.find({Submitter: req.params}).then(documents => {
    console.log(documents);
    res.status(200).json({
      message: "Posts fetched successfully",
      Posts: documents
  });

  });
});

router.post("", (req, res, next) => {
  const exist = new Exist({
    id : req.body.id,
    Submitter : req.body.Submitter,
    CompanyName: req.body.CompanyName,
    ContactName: req.body.ContactName,
    ContactPhone: req.body.ContactPhone,
    ContactEmail: req.body.ContactEmail,
    Description: req.body.Description,
    Product: req.body.Product,
    Status: req.body.Status,
    Points: req.body.Points
  });
  console.log(exist);
  exist.save();
  res.status(201).json({
    message: "Submission Successful!"
  });
});

router.put("/:id", (req, res, next) => {

  if(req.body.Points != null){
    Exist.updateOne({id: req.body.Id}, { Status: req.body.Status, Points: req.body.Points })
  .then(result => {
    console.log(result);

    res.status(200).json({message: "Points and Status Updated!"});
  });
  }else{
    Exist.updateOne({id: req.body.Id}, { CompanyName: req.body.CompanyName, ContactName: req.body.ContactName, ContactPhone: req.body.ContactPhone, ContactEmail: req.body.ContactEmail, Product: req.body.Product, Description: req.body.Description, Status: req.body.Status })
  .then(result => {
    console.log(result);
    res.status(200).json({message: "Post Updated!"});
  });
  }




});

module.exports = router;
