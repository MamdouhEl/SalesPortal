const express = require('express');

const router2 = express.Router();

const NewCustomer = require("../model/newCustomer")



router2.get("", (req, res, next) => {
  NewCustomer.find().then(documents => {
    console.log(documents);
    res.status(200).json({
      message: "Posts fetched successfully",
      Posts: documents
  });

  });
});


router2.post("", (req, res, next) => {
  const Customersnew = new NewCustomer({
    id : req.body.id,
    Submitter : req.body.Submitter,
    CompanyName: req.body.CompanyName,
    ContactName: req.body.ContactName,
    ContactPhone: req.body.ContactPhone,
    ContactEmail: req.body.ContactEmail,
    Description: req.body.Description,
    Status: req.body.Status,
    Points: req.body.Points,
  });
  console.log(Customersnew);
  Customersnew.save();
  res.status(201).json({
    message: "Submission Successful!"
  });
});

router2.put("/:id", (req, res, next) => {

  if(req.body.Points != null){
    NewCustomer.updateOne({id: req.body.Id}, { Status: req.body.Status, Points: req.body.Points })
  .then(result => {
    console.log(result);

    res.status(200).json({message: "Points and Status Updated!"});
  });
  }else{
    NewCustomer.updateOne({id: req.body.Id}, { CompanyName: req.body.CompanyName, ContactName: req.body.ContactName, ContactPhone: req.body.ContactPhone, ContactEmail: req.body.ContactEmail, Description: req.body.Description, Status: req.body.Status })
  .then(result => {
    console.log(result);
    res.status(200).json({message: "Post Updated!"});
  });
  }
});

module.exports = router2;



