var bodyParser = require('body-parser');
const express = require('express');

const admins = express();
admins.use(bodyParser.json());
admins.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
  next();
});

const Admin = require("./model/newAdmin");

const Customers = require("./model/Customers");

const mongoose = require("mongoose");


mongoose.connect("mongodb://EGCSELLAMML1C.corp.emc.com:27017/MyDb").then(() => {
  console.log("Connection to database successful!");
}).catch(() => {
  console.log("Failed Connecting to Database");
});


admins.get("/api/admins", (req, res, next) => {
    var admin = null;
    Admin.find().then(documents => {
      //console.log(documents);
      admin = documents;


    });



    Customers.find().then(documents => {
      //console.log(documents);
      res.status(200).json({
        message: "Posts fetched successfully",
        customers: documents,
        admins: admin
    });

    });


});

admins.delete("/api/admins/:Customername", (req, res, next) => {

  Customers.deleteMany({Customername: req.params.Customername}).then(result => {
    console.log(result);
  });
  res.status(200).json({message: "Post deleted!"});

});

module.exports = admins;
