var bodyParser = require('body-parser');
var path = require("path");
const express = require('express');

const app = express();
app.use(bodyParser.json());
app.use("/", express.static(path.join(__dirname, "Angular")))
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
  next();
});

const userRoutes = require("./routes/user");

const ExistRoutes = require("./routes/Exist");

const NewRoutes = require("./routes/NewC");

const ContactRoutes = require("./routes/Contact");

//const UserSubRoutes = require("./routes/userSub");

const mongoose = require("mongoose");


mongoose.connect("mongodb://EGCSELLAMML1C.corp.emc.com:27017/MyDb").then(() => {
  console.log("Connection to database successful!");
}).catch(() => {
  console.log("Failed Connecting to Database");
});


app.use("/api/newposts",NewRoutes);
app.use("/api/posts",ExistRoutes);
app.use("/api/newcontacts",ContactRoutes);



app.use("/api/user", userRoutes);

//app.use("/api/store", Customer);

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "Angular","index.html"));
});

module.exports = app;
