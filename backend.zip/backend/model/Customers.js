const mongoose = require('mongoose');

const NewPostSchema = mongoose.Schema({
  Customername: {type: String, required: true}
});

module.exports = mongoose.model('Customers', NewPostSchema);
