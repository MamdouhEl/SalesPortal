const mongoose = require('mongoose');

const NewPostSchema = mongoose.Schema({
  username: {type: String, required: true}
});

module.exports = mongoose.model('Admin', NewPostSchema);
