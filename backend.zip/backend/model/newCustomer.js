const mongoose = require('mongoose');

const NewPostSchema = mongoose.Schema({
  id : {type: String, required: true},
  Submitter: {type: String, required: true},
  CompanyName: {type: String, required: true},
  ContactName: {type: String, required: true},
  ContactPhone: {type: String, required: false},
  ContactEmail: {type: String, required: true},
  Description: {type: String, required: false},
  Status: {type: String, required: true},
  Points: {type: String, required: false}
});

module.exports = mongoose.model('NewCustomer', NewPostSchema);
