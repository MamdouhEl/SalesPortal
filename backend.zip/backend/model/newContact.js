const mongoose = require('mongoose');

const NewPostSchema = mongoose.Schema({
  id: {type: String, required: true},
  Submitter: {type: String, required: true},
  Customer: {type: String, required: true},
  ContactName: {type: String, required: true},
  ContactEmail: {type: String, required: true},
  ContactPhone: {type: String, required: false},
  ContactPosition: {type: String, required: false},
  Comment: {type: String, required: false},
  Status: {type: String, required: true},
  Points: {type: String, required: false}
});

module.exports = mongoose.model('NewContact', NewPostSchema);
