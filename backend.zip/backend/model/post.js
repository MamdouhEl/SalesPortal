const mongoose = require('mongoose');

const ExistPostSchema = mongoose.Schema({
  id: {type: String, required: true},
  Submitter: {type: String, required: true},
  CompanyName: {type: String, required: true},
  ContactName: {type: String, required: true},
  ContactPhone: {type: String, required: false},
  ContactEmail: {type: String, required: true},
  Description: {type: String, required: false},
  Product: {type: String, required: true},
  Status: {type: String, required: true},
  Points: {type: String, required: false}
});

module.exports = mongoose.model('Exist', ExistPostSchema);
