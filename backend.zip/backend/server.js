const debug = require("debug")("node-angular");
const http = require("http");
const app = require("./app");
// const NewC = require("./NewC");
const adm = require("./Admin");
const admins = require("./Admins");

const normalizePort = val => {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
};

const onError = error => {
  if (error.syscall !== "listen") {
    throw error;
  }
  const bind = typeof port === "string" ? "pipe " + port : "port " + port;
  switch (error.code) {
    case "EACCES":
      console.error(bind + " requires elevated privileges");
      process.exit(1);
      break;
    case "EADDRINUSE":
      console.error(bind + " is already in use");
      process.exit(1);
      break;
    default:
      throw error;
  }
};

const onListening = () => {
  const addr = server.address();
  const bind = typeof port === "string" ? "pipe " + port : "port " + port;
  debug("Listening on " + bind);
};

 const port = normalizePort(process.env.PORT || "3000");
 const port4 = normalizePort("3003");
 const port5 = normalizePort("3004");
 app.set("port", port);
 adm.set("port", port4);
 admins.set("port", port5);

const server = http.createServer(app);
const server4 = http.createServer(adm);
const server5 = http.createServer(admins);

server.on("error", onError);
server.on("listening", onListening);
server.listen(port);
server4.on("error", onError);
server4.on("listening", onListening);
server4.listen(port4);
server5.on("error", onError);
server5.on("listening", onListening);
server5.listen(port5);
