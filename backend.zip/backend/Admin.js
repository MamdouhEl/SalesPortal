var bodyParser = require('body-parser');
const express = require('express');

const adm = express();
adm.use(bodyParser.json());
adm.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, PUT, OPTIONS");
  next();
});

const Admin = require("./model/newAdmin");

const Customers = require("./model/Customers");

const mongoose = require("mongoose");


mongoose.connect("mongodb://EGCSELLAMML1C.corp.emc.com:27017/MyDb").then(() => {
  console.log("Connection to database successful!");
}).catch(() => {
  console.log("Failed Connecting to Database");
});

adm.post("/api/admins", (req, res, next) => {
  if(req.body.id === 1){
    const admin = new Admin({ username: req.body.admin.Username });
    admin.save()
    //console.log(req.body);
    res.status(201).json({message: "Admin added!"});
  }
  else{
    const customer = new Customers({ Customername: req.body.Cust.Customername });
    customer.save()
    //console.log(req.body);
    res.status(201).json({message: "Customer added!"});
  }
});


adm.get("/api/admins/:username", (req, res, next) => {
  Admin.findOne({username: req.params.username } ).then(documents => {
    console.log(documents);
    if (documents) {
      res.status(200).json({

        message: "Posts fetched successfully",
        Admin: documents


  });
    }
  });
});



adm.delete("/api/admins/:username", (req, res, next) => {


    Admin.deleteOne({username: req.params.username}).then(result => {
      console.log(result);
    });
    res.status(200).json({message: "Post deleted!"});

});



module.exports = adm;
